
from flask import Flask, request, render_template, redirect, session, flash
import sqlite3
import pandas as pd

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Initialize SQLite database for users
conn = sqlite3.connect('users.db')
c = conn.cursor()
c.execute('''
CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    password TEXT NOT NULL
);
''')
conn.commit()
conn.close()

# Initialize a sample backend database using a pandas DataFrame
database_columns = ['Customer_ID', 'Name', 'Email', 'Lost_Item', 'Claim_Status', 'Shipping_Tracking_ID']
database = pd.DataFrame(columns=database_columns)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/claims')
def get_claims():
    if 'username' not in session:
        return redirect('/')
    return render_template('claims.html', claims=database.to_dict('records'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Insert new user into SQLite database
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            flash('Registration successful!', 'success')
        except sqlite3.IntegrityError:
            flash('Username already exists.', 'error')
        finally:
            conn.close()
        
        return redirect('/')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Verify user from SQLite database
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()
        
        if user:
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect('/claims')
        else:
            flash('Invalid credentials', 'error')
    return render_template('login.html')

@app.route('/claim', methods=['GET', 'POST'])
def claim_item():
    if 'username' not in session:
        return redirect('/')
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        lost_item = request.form['lost_item']
        
        new_claim = {
            'Customer_ID': len(database) + 1,
            'Name': name,
            'Email': email,
            'Lost_Item': lost_item,
            'Claim_Status': 'Pending',
            'Shipping_Tracking_ID': ''
        }
        database.loc[len(database)] = new_claim
        flash('Claim submitted successfully!', 'success')
        return redirect('/claims')
    return render_template('claim.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logged out successfully', 'success')
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
