
# SQLite3 Database for User Registration and Login

# Initialize SQLite database
conn = sqlite3.connect('users.db')
c = conn.cursor()

# Create table for users
c.execute('''
CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    password TEXT NOT NULL
);
''')

# Save changes and close connection
conn.commit()
conn.close()

# To insert a new user into the database
conn = sqlite3.connect('users.db')
c = conn.cursor()
c.execute("INSERT INTO users (username, password) VALUES (?, ?)", ('new_user', 'new_password'))
conn.commit()
conn.close()

# To retrieve a user from the database
conn = sqlite3.connect('users.db')
c = conn.cursor()
c.execute("SELECT * FROM users WHERE username=? AND password=?", ('new_user', 'new_password'))
user = c.fetchone()
conn.close()
